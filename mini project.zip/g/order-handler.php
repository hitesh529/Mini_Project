<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'];
    $item = $_POST['item'];
    $quantity = $_POST['quantity'];
    $address = $_POST['address'];
    $contact = $_POST['contact'];

    // Save to file
    $order = "Name: $name\nItem: $item\nQuantity: $quantity\nAddress: $address\nContact: $contact\n---\n";
    file_put_contents("orders.txt", $order, FILE_APPEND);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Order Confirmation</title>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;500;700&display=swap" rel="stylesheet">
  <style>
    body {
      font-family: 'Poppins', sans-serif;
      background-color: #f4f4f9;
      color: #333;
      text-align: center;
      padding: 3rem;
    }
    .card {
      background-color: #fff;
      padding: 2rem;
      margin: auto;
      max-width: 600px;
      border-radius: 10px;
      box-shadow: 0 2px 10px rgba(0,0,0,0.1);
    }
    a {
      display: inline-block;
      margin-top: 1rem;
      text-decoration: none;
      color: #fff;
      background-color: #2d6a4f;
      padding: 0.5rem 1rem;
      border-radius: 5px;
    }
    a:hover {
      background-color: #40916c;
    }
  </style>
</head>
<body>
  <div class="card">
    <h2>Order Received!</h2>
    <p>Thank you, <strong><?php echo isset($name) ? htmlspecialchars($name) : ''; ?></strong>. We'll contact you soon.</p>
    <a href="index.html">Back to Home</a>
  </div>
</body>
</html>
