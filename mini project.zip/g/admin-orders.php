<?php
// Read orders from the text file
$orders = file_exists("orders.txt") ? file_get_contents("orders.txt") : "No orders found.";
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Admin - View Orders</title>
  <style>
    body {
      font-family: 'Poppins', sans-serif;
      background-color: #f4f4f9;
      color: #333;
      padding: 2rem;
      text-align: center;
    }

    .card {
      background-color: #fff;
      padding: 2rem;
      max-width: 700px;
      margin: auto;
      border-radius: 10px;
      box-shadow: 0 0 10px rgba(0,0,0,0.1);
    }

    h2 {
      color: #2d6a4f;
    }

    pre {
      text-align: left;
      background-color: #f1f1f1;
      padding: 1rem;
      border-radius: 5px;
      white-space: pre-wrap;
      word-wrap: break-word;
    }
  </style>
</head>
<body>
  <div class="card">
    <h2>All Orders</h2>
    <pre><?php echo htmlspecialchars($orders); ?></pre>
  </div>
</body>
</html>